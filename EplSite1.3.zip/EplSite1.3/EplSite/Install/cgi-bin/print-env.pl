#!c:\perl\bin\perl -X


#~ print "200 ok\n";
print "content-type: text/html; charset=iso-8859-1\n\n";

print "<HTML>\n";

print "<HEAD>\n";
print "<TITLE>echo cgi env. vars.</TITLE>\n";
print "<H2>Echo CGI Environment Variables</H2>\n";
print "</HEAD>\n";

print "<BODY>\n";
print "<HR>\n";
print "<H3>Environment Variables</H3>\n";
print "<UL>\n";
foreach $key (keys %ENV) {
  print "<LI>$key = $ENV{$key}\n";
  }
print "</UL>\n";
print "</BODY>\n";

print "</HTML>\n";
