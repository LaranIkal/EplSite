cd ..
cd ..
cd ..
cd ..
cd ..
./hypertextperl.pl htdocs/eplsite/modules/EplSiteETL/BatchProcess/ScriptBatchProcess.ppl Script 3 ETLSample 2 9 9 tmp