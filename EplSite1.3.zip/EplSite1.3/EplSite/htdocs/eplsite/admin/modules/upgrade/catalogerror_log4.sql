CREATE INDEX "eplsite_etl_catalogerror_log_idx2" 
ON "eplsite_etl_catalogerror_log" ("DateTime" ASC, "ETLUser" ASC)