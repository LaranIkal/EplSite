INSERT INTO "eplsite_reports_definition" VALUES ("5","XRefErrorLog","4","Xref Transformations Error Log.","########################################################################
# Eplsite ETL XRef Error Log Report script 
#Copyright (C) 2012 by Carlos Alberto Kassab (laran.ikal@gmail.com)
########################################################################

our( $oracle_connection, @the_cvalues, $MyQuery );
our $RecordsDisplayedCounter = 0;
our $offset = 40;
our $min = 0 if( !defined($fdat{min}) );
$min = $fdat{min} if( defined($fdat{min}) );
our $max = ($min + $offset) if( !defined($max) );	
@the_cvalues = $globalp->{get_the_cookie}();

if( $fdat{reportoption} eq """" or not defined($fdat{reportoption}) )
{
  $globalp->{siteheader}();
  $globalp->{LoadJavaScriptLibrary}(""LogsEplSiteETL"");
  $globalp->{theheader}();
  $globalp->{OpenTable}();
  
  &Report_Menu();	
  
  $globalp->{CloseTable}();
  $globalp->{loggedon_as}();
  $globalp->{sitefooter}();
  $globalp->{clean_exit}();		
}
elsif( $fdat{reportoption} eq ""processreport"" )
{
	$ValidationResult = &ValidatePostedFormData();

  if( $ValidationResult eq ""ValidationOk"" )
  {
    ## If the process was not stopped before, it is executed
    
    my $ProcessReport = &Process_Data();
    
    if( $ProcessReport == 0 )
    {
      echo(""No Data Found For Report."");
    }
  }
  else
  {
  	echo($ValidationResult);
  }
}
	



############################# Sub Routines #######################################

	sub ValidatePostedFormData
	{
		my $ValidationMessage = """";
		
		$fdat{datetimefrom} =~ s/^\s+//; #remove leading spaces
		$fdat{datetimefrom} =~ s/\s+$//; #remove trailing spaces

		$fdat{datetimeto} =~ s/^\s+//; #remove leading spaces
		$fdat{datetimeto} =~ s/\s+$//; #remove trailing spaces

		$fdat{runnumberfrom} =~ s/^\s+//; #remove leading spaces
		$fdat{runnumberfrom} =~ s/\s+$//; #remove trailing spaces

		$fdat{runnumberto} =~ s/^\s+//; #remove leading spaces
		$fdat{runnumberto} =~ s/\s+$//; #remove trailing spaces

		$fdat{etluserfrom} =~ s/^\s+//; #remove leading spaces
		$fdat{etluserfrom} =~ s/\s+$//; #remove trailing spaces

		$fdat{etluserto} =~ s/^\s+//; #remove leading spaces
		$fdat{etluserto} =~ s/\s+$//; #remove trailing spaces
    
		if( $fdat{datetimefrom} eq """" )
		{
			$fdat{datetimefrom} = 0;
		}
    
		if( $fdat{datetimeto} eq """" )
		{
			$fdat{datetimeto} = $fdat{datetimefrom};
		}
    
    if( $fdat{datetimefrom} < """" && $fdat{datetimeto} ne """" ) 
    {
    	$ValidationMessage .= ""Date Time To Must be Greater or Equal to Date Time From."";
    }
    
		if( $fdat{runnumberfrom} ne """" && $fdat{runnumberto} eq """" )
		{
			$ValidationMessage .= ""Enter Both Run Numbers.<br>"";
		}

		if( $fdat{runnumberto} ne """" && $fdat{runnumberfrom} eq """" )
		{
			$ValidationMessage .= ""Enter Both Run Numbers.<br>"";
		}
    
    if( $fdat{runnumberfrom} ne """" && $fdat{runnumberto} ne """" )
    {
      if( $fdat{runnumberfrom} < """" && $fdat{runnumberto} ne """" ) 
      {
        $ValidationMessage .= ""Run Number To Must be Greater or Equal to Run Number From."";
      }
    }		

		if( $fdat{etluserfrom} ne """" && $fdat{etluserto} eq """" ) 
		{
			$fdat{etluserto} = $fdat{etluserfrom};
		}
					
		if( $ValidationMessage eq """" )
		{
			$ValidationMessage = ""ValidationOk"";
		}
		
		return( $ValidationMessage );
	}





	sub Report_Menu
	{
		
		$fdat{searchfield} =~ s/%//g;
		echo(""<b><big>EplSite ETL XRef Error Logs Report.</big></b><br><br>"");

		echo(""<form name=\""form2\"" action=\""index.prc\"" method=\""post\"">""
    .""<input type=\""hidden\"" name=\""module\"" value=\""EplSiteReports\"">\n""
    .""<input type=\""hidden\"" name=\""min\"" value=\""0\"">\n""
    .""<input type=\""hidden\"" name=\""option\"" value=\""executereport\"">\n""
    .""<input type=\""hidden\"" name=\""servertype\"" value=\""$fdat{servertype}\"">\n""
    .""<input type=\""hidden\"" name=\""company\"" value=\""$fdat{company}\"">\n""
    .""<input type=\""hidden\"" name=\""reportoption\"" value=\""processreport\"">\n""
    .""<input type=\""hidden\"" name=\""ReportID\"" value=\""$fdat{ReportID}\"">\n""
    .""<fieldset><legend><font color=\""red\"">Dates are mandatory fields</font></legend>\n""
    .""<b>Date Time From: </b><input type=\""text\"" id=\""datetimefrom\"" name=\""datetimefrom\"" value=\""$fdat{datetimefrom}\""""
    ."" size =\""30\"" onkeydown='testForEnter();' onblur='SetToValue(\""datetimefrom\"",\""datetimeto\"");'>(YYYYMMDDHHMISS)�� - ��\n""
    .""<b>Date Time To: </b><input type=\""text\"" id=\""datetimeto\"" name=\""datetimeto\"" value=\""$fdat{datetimeto}\""""
    ."" size =\""30\"" onkeydown='testForEnter();'>(YYYYMMDDHHMISS)<br>\n""
    .""</fieldset>\n""
    .""<b>Run Number From: </b><input type=\""text\"" id=\""runnumberfrom\"" name=\""runnumberfrom\"" value=\""$fdat{runnumberfrom}\""""
    ."" size =\""30\"" onkeydown='testForEnter();' onblur='SetToValue(\""runnumberfrom\"",\""runnumberto\"");'>�� - ��\n""
    .""<b>Run Number To: </b><input type=\""text\"" id=\""runnumberto\"" name=\""runnumberto\"" value=\""$fdat{runnumberto}\""""
    ."" size =\""30\"" onkeydown='testForEnter();'><br>\n""    
    .""<b>ETL User Login From: </b><input type=\""text\"" id=\""etluserfrom\"" name=\""etluserfrom\"" value=\""$fdat{etluserfrom}\""""
    ."" size =\""30\"" onkeydown='testForEnter();' onblur='SetToValue(\""etluserfrom\"",\""etluserto\"");'>�� - ��\n""
    .""<b>ETL User Login To: </b><input type=\""text\"" id=\""etluserto\"" name=\""etluserto\"" value=\""$fdat{etluserto}\""""
    ."" size =\""30\"" onkeydown='testForEnter();'><br>\n""
    .""<b>Report To Display: </b>""
    .""<input type=\""checkbox\"" checked name=\""reportindisplay\"" value=\""Yes\""><br><br>\n""
    .""<input type=\""button\"" VALUE=\""Display / Export Report\""""
    ."" onclick='JavaScript:xmlhttpPost(\""index.prc\"",this.form,\""SearchResult\"")'><br><br>\n""
    .""</form>\n""
    .""<fieldset><div id=\""SearchResult\"">Search Results Will Be Displayed Here</div></fieldset>\n"");	
	}
	




	sub Process_Data
	{		
		my $MyQuery = ""SELECT RunNumber, DateTime, ETLUser,ETLSchemeCode, TransformationCode "";
		$MyQuery .= "" ,FieldDescription, ActualValue1,ActualValue2, LogMessage"";
		$MyQuery .= "" FROM "".$globalp->{table_prefix}.""_etl_xreferror_log"";
		$MyQuery .= "" WHERE DateTime BETWEEN "";
		$MyQuery .= $fdat{datetimefrom} . "" AND "" . $fdat{datetimeto};
    if( not $globalp->{isspace}($fdat{runnumberfrom}) )
    {
      $MyQuery .= "" AND RunNumber BETWEEN "";
      $MyQuery .= $fdat{runnumberfrom} . "" AND "" . $fdat{runnumberto};
    }    
    if( not $globalp->{isspace}($fdat{etluserfrom}) )
    {
      $MyQuery .= "" AND ETLUser BETWEEN '"";
      $MyQuery .= $fdat{etluserfrom} . ""' AND '"" . $fdat{etluserto}.""'"";
    }
		$MyQuery .= "" ORDER BY  RunNumber, DateTime"";
		#echo(""Processing query:$MyQuery""); exit;
    
    $globalp->{dbh}->{RaiseError} = 1;
    eval {
							$GetMyQuery = $globalp->{dbh}->prepare ($MyQuery);
           };
		if($@)
    {
    	echo(""Cannot prepare query: <font color=\""red\""><b>$MyQuery</b></font>"");
      $globalp->{clean_exit}();	
    }
    
    eval {
							$GetMyQuery -> execute();
           };
		if($@)
    {
    	echo(""Cannot execute query: <font color=\""red\""><b>$MyQuery</b></font>"");
      $globalp->{clean_exit}();	
    }
               
		my $NumberOfFields = $GetMyQuery->{NUM_OF_FIELDS};
		
		my $MyOraQueryRows = [];
		my %QueryValues = ();
		$RecordsDisplayedCounter = 1;
		my $HeaderPrinted = 0;
		
		$DataFound = 0;
		while ( ( my $MyQueryRow = (shift(@$MyOraQueryRows) || shift(@{$MyOraQueryRows=$GetMyQuery->fetchall_arrayref(undef,1)||[]}))) && $RecordsDisplayedCounter <= $max )
		{				
			$TheOraQueryRow = join(""\~"", @{$MyQueryRow});
			@OraQueryArray = split(""\~"", $TheOraQueryRow);
	
			for(  my $Count = 0; $Count < $NumberOfFields; $Count++ ){
				$QueryValues{$GetMyQuery->{NAME}[$Count]} = @{$MyQueryRow}[$Count];
			}		

			if( $HeaderPrinted == 0 )
			{
      	$DataFound = 1;
				if( $fdat{reportindisplay} eq ""Yes"" )					
				{
					my $ReportHeaderLine = ""<th>Seq.</th>"";				
					$ReportHeaderLine .= ""<th>RunNumber</th><th>DateTime</th>\n"";
					$ReportHeaderLine .= ""<th>ETLUser</th><th>ETLSchemeCode</th>\n"";
					$ReportHeaderLine .= ""<th>TransformationCode</th><th>Field Description</th>\n"";
          $ReportHeaderLine .= ""<th>Actual Value 1</th><th>Actual Value 2</th>\n"";
          $ReportHeaderLine .= ""<th>LogMessage</th>\n"";
					
					echo(""<table width=\""100%\"" cellspacing=\""0\"" cellpadding=\""0\"" border=\""1\"" align=\""center\"">\n""
					.""<tr bgcolor=\""$globalp->{bgcolor4}\"">$ReportHeaderLine</tr>\n"");	
				}
				else
				{
					$ReportHeaderLine = ""RunNumber\|DateTime\|ETLUser\|"";
					$ReportHeaderLine .= ""ETLSchemeCode\|TransformationCode\|FieldDescription\|"";
          $ReportHeaderLine .= ""ActualValue1\|ActualValue2\|LogMessage\|"";

					&create_report_header($ReportHeaderLine,""EplSiteETLXRefErrorLog"",""txt""); ## Set Report Header, File Name,Extension
				}
				$HeaderPrinted = 1;
			}			
				
			if( $fdat{reportindisplay} eq ""Yes"" )
			{
				if( $RecordsDisplayedCounter > $min  )
				{	
					print ""<tr bgcolor=\""$globalp->{bgcolor3}\""><td>"".$RecordsDisplayedCounter.""</td>"";
					print ""<td>"".$QueryValues{'RunNumber'} . ""</td><td>"" . $QueryValues{'DateTime'} . ""</td>"";
					print ""<td>"".$QueryValues{'ETLUser'} . ""</td><td>"" . $QueryValues{'ETLSchemeCode'} . ""</td>"";
					print ""<td>"".$QueryValues{'TransformationCode'} . ""</td><td>"" . $QueryValues{'FieldDescription'} . ""</td>"";
          print ""<td>"".$QueryValues{'ActualValue1'} . ""</td><td>"" . $QueryValues{'ActualValue2'} . ""</td>"";
          print ""<td>"".$QueryValues{'LogMessage'} . ""</td>"";
					print ""</tr>"";
				}
				$RecordsDisplayedCounter++;
			}
			else
			{
				print $QueryValues{'RunNumber'} . ""\|"" . $QueryValues{'DateTime'} . ""\|"";
				print $QueryValues{'ETLUser'} . ""\|"" . $QueryValues{'ETLSchemeCode'} . ""\|"";
				print $QueryValues{'TransformationCode'} . ""\|"" . $QueryValues{'FieldDescription'} . ""\|"";
        print $QueryValues{'ActualValue1'} . ""\|"" . $QueryValues{'ActualValue2'} . ""\|"";
        print $QueryValues{'LogMessage'} . ""\|"";
				print ""\n"";	
			}
				
		}
		$GetMyQuery ->finish();
		
		if( $fdat{reportindisplay} eq ""Yes"" )
		{		
			$prev = $RecordsDisplayedCounter - ( $offset * 2 ) -1;
			$prev = 0 if( $prev < 0 );
			$NumberOfFields +=1;

			echo(""<tr><td colspan=\"""".$NumberOfFields.""\""><table align=\""left\"" border=\""0\""><tr>"");
			if( ( $RecordsDisplayedCounter - 1 ) > $offset )
			{			
				echo(""<td><center><form name=\""FormPreviousMatches\"" action=\""index.prc\"" method=\""post\"">\n""
        .""<input type=\""hidden\"" name=\""module\"" value=\""EplSiteReports\"">\n""
        .""<input type=\""hidden\"" name=\""min\"" value=\""$prev\"">\n""
        .""<input type=\""hidden\"" name=\""option\"" value=\""$fdat{option}\"">\n""
        .""<input type=\""hidden\"" name=\""servertype\"" value=\""$fdat{servertype}\"">\n""
        .""<input type=\""hidden\"" name=\""company\"" value=\""$fdat{company}\"">\n""
        .""<input type=\""hidden\"" name=\""reportoption\"" value=\""$fdat{reportoption}\"">\n""
        .""<input type=\""hidden\"" name=\""ReportID\"" value=\""$fdat{ReportID}\"">\n""
        .""<input type=\""hidden\"" name=\""reportindisplay\"" value=\""$fdat{reportindisplay}\"">\n""
        #~ .""<input type=\""hidden\"" name=\""UseAjax\"" value=\""1\"">\n""
        .""<input type=\""button\"" Name=\""process\"" VALUE=\""Previous $min Matches.\""""
        ."" OnClick='JavaScript:xmlhttpPostNavigation(\""index.prc\"",this.form,\""SearchResult\"")'></form></center></td>"");
			}
			$next = $RecordsDisplayedCounter + $offset;

			if( $RecordsDisplayedCounter > ( $min + $offset ) )
			{
				echo(""<td><center><form name=\""FormNextMatches\"" action=\""index.prc\"" method=\""post\"">\n""
        .""<input type=\""hidden\"" name=\""module\"" value=\""EplSiteReports\"">\n""
        .""<input type=\""hidden\"" name=\""min\"" value=\""$max\"">\n""
        .""<input type=\""hidden\"" name=\""option\"" value=\""$fdat{option}\"">\n""
        .""<input type=\""hidden\"" name=\""servertype\"" value=\""$fdat{servertype}\"">\n""
        .""<input type=\""hidden\"" name=\""company\"" value=\""$fdat{company}\"">\n""
        .""<input type=\""hidden\"" name=\""reportoption\"" value=\""$fdat{reportoption}\"">\n""
        .""<input type=\""hidden\"" name=\""ReportID\"" value=\""$fdat{ReportID}\"">\n""
        .""<input type=\""hidden\"" name=\""reportindisplay\"" value=\""$fdat{reportindisplay}\"">\n""
        #~ .""<input type=\""hidden\"" name=\""UseAjax\"" value=\""1\"">\n""
        .""<input type=\""button\"" Name=\""process\"" VALUE=\""Next Matches.\""""
        ."" OnClick='JavaScript:xmlhttpPostNavigation(\""index.prc\"",this.form,\""SearchResult\"")'></form></center></td>"");							
			}
			echo(""</table>"");
			
			echo(""<p><b>"".$globalp->{GetNumberOfRecordsInQuery}($globalp->{dbh},$MyQuery,9).""</b> Records Found.</p>"");
		}		
		return( $DataFound );
	}
	
	
");