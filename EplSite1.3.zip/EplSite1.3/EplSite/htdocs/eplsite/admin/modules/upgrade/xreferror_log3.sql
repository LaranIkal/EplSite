CREATE INDEX "eplsite_etl_xreferror_log_idx1" 
ON "eplsite_etl_xreferror_log" 
("RunNumber" ASC, "FieldDescription" ASC, "ActualValue1" ASC, "ActualValue2" ASC)