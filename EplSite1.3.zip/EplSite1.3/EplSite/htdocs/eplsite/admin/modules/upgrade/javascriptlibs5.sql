INSERT INTO "eplsite_etl_javascriptlibs" VALUES ("1","LogsEplSiteETL","JavaScript Libs For EplSiteETL Logs Report","	function xmlhttpPostNavigation(strURL,EplSiteform,DivField) 
	{
		var xmlHttpReq = false;
		var self = this;
		var qstr = """";
		// Getting form data
		var FormEplSite = EplSiteform;
	
		var ThereIsError = ValidateData();
		
		if( ThereIsError != """" )
		{
			document.getElementById(DivField).innerHTML = ThereIsError;
		}	
		else
		{
			TheTimeOut = setTimeout(""document.body.style.cursor='wait'"", 1);
			try
			{		
				document.getElementById(DivField).innerHTML = ""Processing, please wait..."";
				// Mozilla/Safari/Chrome
				if (window.XMLHttpRequest) 
				{
					self.xmlHttpReq = new XMLHttpRequest();
				}
				// IE
				else if (window.ActiveXObject) 
				{
					self.xmlHttpReq = new ActiveXObject(""Microsoft.XMLHTTP"");
				}
				
				self.xmlHttpReq.open('POST', strURL, true);
				self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
				self.xmlHttpReq.onreadystatechange = function() 
				{
					if (self.xmlHttpReq.readyState == 4) 
					{				
						updatepage(self.xmlHttpReq.responseText,DivField);
						clearTimeout(TheTimeOut); 
						document.body.style.cursor='default';					
					}
				}
				self.xmlHttpReq.send(getquerystring(FormEplSite));
			}
			catch(err){clearTimeout(TheTimeOut); document.body.style.cursor='default';}
		}
	}
	



	
	
	function xmlhttpPost(strURL,EplSiteform,DivField) 
	{	
		var ThereIsError = ValidateData();
		
		if( ThereIsError != """" )
		{
			document.getElementById(DivField).innerHTML = ThereIsError;
		}		
		else
		{
			if(EplSiteform.reportindisplay.checked==1)
			{
				TheTimeOut = setTimeout(""document.body.style.cursor='wait'"", 1);
				try
				{
					updatepage(""Processing, please wait..."",DivField);
					xmlhttpPost2(strURL,EplSiteform,DivField);
				}
				catch(err){ clearTimeout(TheTimeOut); document.body.style.cursor='default'; }
			}
			else
			{
				EplSiteform.submit();
			}
		}
	}

	
	
	
	function xmlhttpPost2(strURL,EplSiteform,DivField) 
	{
		var xmlHttpReq = false;
		var self = this;

		// Mozilla/Safari/Chrome
		if (window.XMLHttpRequest) 
		{
			self.xmlHttpReq = new XMLHttpRequest();
		}
		// IE
		else if (window.ActiveXObject) 
		{
			self.xmlHttpReq = new ActiveXObject(""Microsoft.XMLHTTP"");
		}
		
		self.xmlHttpReq.open('POST', strURL, true);
		self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		self.xmlHttpReq.onreadystatechange = function() 
		{
			if (self.xmlHttpReq.readyState == 4) 
			{
				updatepage(self.xmlHttpReq.responseText,DivField);
				clearTimeout(TheTimeOut);
				document.body.style.cursor='default';
			}
		}
		self.xmlHttpReq.send(getquerystring(EplSiteform));
	}
	
		
		
	function getquerystring(QueryEplSiteform5) 
	{
		var FormEplSite = QueryEplSiteform5;
		//~ alert(formEplSite.module.value);
		var module = FormEplSite.module.value;
		var option = FormEplSite.option.value;
		var servertype = FormEplSite.servertype.value;
		var company = FormEplSite.company.value;
		var reportoption = FormEplSite.reportoption.value;
		var ReportID = FormEplSite.ReportID.value;
		var datetimefrom = document.getElementById('datetimefrom').value.replace(/^\s+|\s+$/g,'');
		var datetimeto = document.getElementById('datetimeto').value.replace(/^\s+|\s+$/g,'');
		var runnumberfrom = document.getElementById('runnumberfrom').value.replace(/^\s+|\s+$/g,'');
		var runnumberto = document.getElementById('runnumberto').value.replace(/^\s+|\s+$/g,'');    
		var etluserfrom = document.getElementById('etluserfrom').value.replace(/^\s+|\s+$/g,'');
		var etluserto = document.getElementById('etluserto').value.replace(/^\s+|\s+$/g,'');		
		var min = FormEplSite.min.value;
		var reportindisplay = FormEplSite.reportindisplay.value;
		
		qstr = 'module=' + escape(module);  // NOTE: no '?' before querystring
		qstr += '&option=' + escape(option); 
		qstr += '&servertype=' + escape(servertype); 
		qstr += '&company=' + escape(company); 
		qstr += '&reportoption=' + escape(reportoption); 
		qstr += '&ReportID=' + escape(ReportID); 
		qstr += '&datetimefrom=' + escape(datetimefrom);
		qstr += '&datetimeto=' + escape(datetimeto);
		qstr += '&runnumberfrom=' + escape(runnumberfrom);
		qstr += '&runnumberto=' + escape(runnumberto);    
		qstr += '&etluserfrom=' + escape(etluserfrom);
		qstr += '&etluserto=' + escape(etluserto);		
		qstr += '&min=' + escape(min);	
		qstr += '&reportindisplay=' + escape(reportindisplay);
		
		return qstr;
	}




	function ValidateData()
	{
		var ValidationMessage = """";
		
		var datetimefrom = document.getElementById('datetimefrom').value.replace(/^\s+|\s+$/g,'');
		var datetimeto = document.getElementById('datetimeto').value.replace(/^\s+|\s+$/g,'');
		var etluserfrom = document.getElementById('etluserfrom').value.replace(/^\s+|\s+$/g,'');
		var etluserto = document.getElementById('etluserto').value.replace(/^\s+|\s+$/g,'');		
	
		if( datetimeto == """" )
		{
			ValidationMessage += ""<br><b>\""Date Time To\"" Must Have a Value</b>"";
		}
		
		return ValidationMessage;
	}




	function updatepage(str,DivFieldToUpdate)
	{		
		document.getElementById(DivFieldToUpdate).innerHTML = str;
	}



	function testForEnter() 
	{    
		if (event.keyCode == 13) 
		{        
			event.cancelBubble = true;
			event.returnValue = false;
		}
	} 



	function SetToValue(FromDivField,ToDivField)
	{		
		var ToFieldValue = document.getElementById(ToDivField).value;
    
    if( ToFieldValue == """" )
    {
      document.getElementById(ToDivField).value = document.getElementById(FromDivField).value;
    }
	}



	function ConfirmSubmit(Question)
	{
		var answer = confirm(Question);
		if (answer)
			return true;
		else
			return false;
	}



");