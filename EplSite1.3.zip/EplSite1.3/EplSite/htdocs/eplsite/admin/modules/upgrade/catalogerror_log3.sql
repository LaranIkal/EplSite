CREATE INDEX "eplsite_etl_catalogerror_log_idx1" 
ON "eplsite_etl_catalogerror_log" 
("RunNumber" ASC, "FieldDescription" ASC, "CatalogValue1" ASC, "CatalogValue2" ASC)