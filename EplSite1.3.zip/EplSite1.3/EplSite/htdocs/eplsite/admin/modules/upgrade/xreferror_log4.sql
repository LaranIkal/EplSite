CREATE INDEX "eplsite_etl_xreferror_log_idx2" 
ON "eplsite_etl_xreferror_log" ("DateTime" ASC, "ETLUser" ASC)