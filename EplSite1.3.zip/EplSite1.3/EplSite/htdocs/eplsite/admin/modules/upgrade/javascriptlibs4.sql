CREATE INDEX "eplsite_etl_javascriptlibs_idx2" 
ON "eplsite_etl_javascriptlibs" ("JavaScriptName" ASC)