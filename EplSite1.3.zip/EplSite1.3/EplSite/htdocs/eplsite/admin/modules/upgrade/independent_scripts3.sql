INSERT INTO "eplsite_etl_independent_scripts" VALUES ("3","Just an Independent Script Sample","IndePendentScriptSample.prc","ETLSample","  our( $dbsource_conn, $dbtarget_conn, @the_cvalues );
	@the_cvalues = $globalp->{get_the_cookie}();
	
  if( $ENV{BATCH_PROCESS} == 0 )
  {
    $globalp->{siteheader}();
    $globalp->{theheader}();
    $globalp->{OpenTable}(); 
	}
    
	if( $fdat{scriptoption} eq ""extractdata"" )
	{
		$fdat{TransformationCodeFrom} = $globalp->{All_Trim}($fdat{TransformationCodeFrom});
		$fdat{TransformationCodeTo} = $globalp->{All_Trim}($fdat{TransformationCodeTo});
		
		#Removing non printing chars
		$fdat{TransformationCodeFrom} =~ s/[^[:print:]]//g;
		$fdat{TransformationCodeTo} =~ s/[^[:print:]]//g;
		
		$ValidationResult = &ValidatePostedFormData();      
		
		if( $ValidationResult eq ""ValidationOk"" )
		{
			## If the process was not stopped before, it is executed

			$dbsource_conn = $globalp->{connect_data_source}($fdat{DBConnSourceID});
			$dbtarget_conn = $globalp->{connect_data_source}($fdat{DBConnTargetID});
      
      my $ScriptMessage = ""This process is a sample, it gets transformation codes\n"";
				$ScriptMessage .= ""and save them in general_data table.\n"";
        $ScriptMessage .= ""Process start:"".$globalp->{get_localtime}(time).""\n\n"";
        
			if( $ENV{BATCH_PROCESS} == 0 )
      {
      	$ScriptMessage =~ s/\n/<br>/g;
      }
      
      print $ScriptMessage;
      
			my $deletequery = ""DELETE FROM GENERAL_DATA"";
			$deletequery .= "" WHERE kindofdata = 'etlscriptsample'"";

			$dbtarget_conn->do($deletequery);
			
			$ProcessScript = &get_transformation_definitions();

			if( defined( $dbsource_conn ))
			{
				eval { $dbsource_conn->disconnect(); };
				undef $dbsource_conn if($@);
			}
			
			if( defined( $dbtarget_conn ))
			{
				eval { $dbtarget_conn->disconnect(); };
				undef $dbtarget_conn if($@);
			}
			
      $ScriptMessage = ""<br><br>Process end:"".$globalp->{get_localtime}(time).""<br><br>"";
      
			if( $ENV{BATCH_PROCESS} == 1 )
      {
      	$ScriptMessage =~ s/<br>/\n/g;
        print $ScriptMessage;
      }
      else
      {
      	print $ScriptMessage;      
      	echo($globalp->{_GOBACK});
      }
		}
		else
		{	
			echo($ValidationResult.""<br><br>"".$globalp->{_GOBACK});			
		}
	}
	else
	{	
		&Display_Menu();	
	}

	if( $ENV{BATCH_PROCESS} == 0 )
  {
    $globalp->{CloseTable}();
    $globalp->{loggedon_as}();
    $globalp->{sitefooter}();
  }
  

  $globalp->{clean_exit}();	
    
############################# Sub Routines #######################################

	sub ValidatePostedFormData
	{
		$ValidationMessage = """";
		
		if( $fdat{TransformationCodeFrom} eq """" or not defined($fdat{TransformationCodeFrom}) )
		{
			$ValidationMessage .= ""Transformation Code From must have a valid value.<br>"";
		}

		if( $fdat{TransformationCodeTo} eq """" or not defined($fdat{TransformationCodeTo}) )
		{
			$ValidationMessage .= ""Transformation Code To must have a valid value.<br>"";
		}
		
		if( $ValidationMessage eq """" )
		{
			$ValidationMessage = ""ValidationOk"";
		}
		
		return( $ValidationMessage );
	}




	sub Display_Menu
	{	

		my $selectquery = ""SELECT ETLSchemeDescription FROM "".$globalp->{table_prefix};
		$selectquery .= ""_etl_schemes WHERE ETLSchemeID = $fdat{ETLSchemeID}"";		
		$resulti = $globalp->{dbh} -> prepare ($selectquery) 
		or die ""Cannot prepare query:$selectquery"";
		$resulti -> execute  or die ""Cannot execute:$selectquery"";
		$resulti -> bind_columns(undef, \$ETLSchemeDescription);
		$datresulti = $resulti -> fetchrow_arrayref;
		$resulti->finish();

		echo(""<b><big>Exporting Transformations as Independent Script Sample.</big></b><br><br>""
				.""<b>ETL Scheme: </b>$fdat{sourcesystem} - $ETLSchemeDescription <br>""
				.""<b>Data Base Connection Source: </b>$fdat{DBConnSourceID},""
				.""<b>Data Base Connection Target: </b>$fdat{DBConnSourceID}<br><br>"");
				
		echo(""<form action=\""index.prc\"" method=\""post\"">\n""
				.""<input type=\""hidden\"" name=\""module\"" value=\""EplSiteETL\"">\n""
				.""<input type=\""hidden\"" name=\""option\"" value=\""extractdata\"">\n""
				.""<input type=\""hidden\"" id=\""ETLSchemeCode\"" name=\""ETLSchemeCode\"" value=\""$fdat{ETLSchemeCode}\"">\n""
				.""<input type=\""hidden\"" name=\""ETLSchemeID\"" value=\""$fdat{ETLSchemeID}\"">\n""
				.""<input type=\""hidden\"" name=\""scriptoption\"" value=\""extractdata\"">\n""
				.""<input type=\""hidden\"" id=\""DBConnSourceID\"" name=\""DBConnSourceID\"" value=\""$fdat{DBConnSourceID}\"">\n""
				.""<input type=\""hidden\"" id=\""DBConnTargetID\"" name=\""DBConnTargetID\"" value=\""$fdat{DBConnTargetID}\"">\n""
				.""<input type=\""hidden\"" name=\""ScriptID\"" value=\""$fdat{ScriptID}\"">\n""
				.""<table>""
				.""<tr><td><fieldset><legend>Filter By Transformation Code</legend><b>Trasnformation Code From: </b>\n""
				.""<input type=\""text\"" id=\""TransformationCodeFrom\"" name=\""TransformationCodeFrom\"" value=\""\"" size=\""10\""""
				."" onkeydown='testForEnter();'>\n""
				.""��<b>Trasnformation Code To: </b>""
				.""<input type=\""text\"" id=\""TransformationCodeTo\"" name=\""TransformationCodeTo\"" value=\""\"" size=\""10\""""
				."" onkeydown='testForEnter();'>\n""
				.""</fieldset></td></tr>\n""
				.""<tr><td><input type=\""submit\"" VALUE=\""Execute\"">""
				#~ ."" onclick='JavaScript:xmlhttpPostNavigation(\""index.prc\"",this.form,\""ResultPane\"")'>\n""
				.""</td><td>�</td></tr>\n""
				.""</table></form>\n"");
				#~ .""<fieldset><legend>Submitted Data Results.</legend><div id=\""ResultPane\"">"");
								
				#~ &CreateActiveAndBlockedItemsLink();
				
				echo(""</div></fieldset>\n"");
        echo(""<br><br>"".$globalp->{_GOBACK});	
	}




	sub get_transformation_definitions
	{	
		
		my $InsertQuery = ""INSERT INTO GENERAL_DATA (KINDOFDATA,DATAFIELD1,DATAFIELD2"";
		$InsertQuery .= "",DATAFIELD3) VALUES ("";
		$InsertQuery .= ""?,?,?,?)"";			
		my $TInsert = $dbtarget_conn->prepare($InsertQuery);
		
		my $KindOfData = ""etlscriptsample"";
		
		my $TQuery = ""SELECT ETLSchemeID,TransformationCode, Description"";
		$TQuery .= "" FROM eplsite_etl_transformation_definitions"";

		my $GetQuery = $dbsource_conn->prepare ($TQuery) or die ""Cannot prepare:$TQuery"";
		$GetQuery -> execute or die ""Cannot execute:$TQuery"";
		$GetQuery ->{RaiseError} = 1;

		my $QueryRows = [];
		my $QueryArray =[];
		
		print ""Getting Transformation Definitions...\n"";
		
		$OurItemsCounter = 0;
		$ItemsExtracted = 0;
		while ( my $QueryRow = (shift(@$QueryRows) || shift(@{$QueryRows=$GetQuery->fetchall_arrayref(undef,1)||[]})))
		{	
			my $TheQueryRow = join(""\~"", @{$QueryRow});
			@QueryArray = split(""\~"", $TheQueryRow);	
			
			$TInsert->execute($KindOfData,$QueryArray[0],$QueryArray[1],$QueryArray[2])
			or die ""Data can not be inserted in general_data table"";
		}
		$GetQuery ->finish();
		$TInsert->finish();		
	}





");