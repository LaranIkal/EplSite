CREATE UNIQUE INDEX "eplsite_etl_javascriptlibs_idx1" 
ON "eplsite_etl_javascriptlibs" ("JavaScriptID" ASC)