CREATE TABLE "eplsite_etl_catalogerror_log" (
"RunNumber" NUMERIC NOT NULL DEFAULT 0
, "DateTime" NUMERIC NOT NULL  DEFAULT 0
, "ETLUser" VARCHAR NOT NULL 
, "ETLSchemeCode" VARCHAR NOT NULL 
, "TransformationCode" VARCHAR NOT NULL 
, "FieldDescription" VARCHAR  
, "CatalogValue1" VARCHAR  
, "CatalogValue2" VARCHAR  
, "LogMessage" TEXT NOT NULL );
