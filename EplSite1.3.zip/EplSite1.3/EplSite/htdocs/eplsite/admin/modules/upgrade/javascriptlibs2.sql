CREATE TABLE "eplsite_etl_javascriptlibs" (
"JavaScriptID" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE 
, "JavaScriptName" VARCHAR NOT NULL 
, "JavaScriptDescription" VARCHAR NOT NULL 
, "JavaScriptCode" TEXT);