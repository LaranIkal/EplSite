Blocks System
======================


It is very similar to PHP-Nuke. You can add new blocks by simply copying the blocks
files into its directory /blocks/.

Please read this doc carefully and remember that this system, as the whole
system comes without any warranty and all you do from here is under
your own responsability and risk. Always remember to backup your
database and all your files before doing anything.


====================================
1.- Introduction to Use Block Files
====================================

We start on the "blocks" directory where you can add or delete all the
blocks' files you want.

The filenames under /blocks/ dir have two rules to work properly:

a) All spaces are filled with "_", so if you have a block called for example
   Quote of the Day, your filename need to be: block-Quote_of_the_Day.php
   Note the "block-" at the begining of the filename and the ".php" extension,
   both are needed in order to properly add a block from the administration.
   
b) All blocks needs to return a variable with the content called $content,
   you can see the Sample Block included.
   
All files in this directory that start with "block-" and have the .php extension
will be included in the selection form in the administration interfase, otherwise
you will not see anything.

To add the new block, go to administration interfase and select your new block
from the "Filename" field in the Blocks section.

If you don't write a Title for your block, by default the system will get the
title from the filename stripping the "_" characters and converting it into spaces.

If you created a block and then you delete the file, the system automaticaly will
show an error message on your block, also if there isn't any content in the $content
variable from your file.

When install a new block please be sure that the blank spaces on the filename
are replaced with "_", for Example: The_Weather. The filename is case sensitive,
this mean that isn't the same the_weather and The_Weather. The "_" character is
replaced automaticaly by a blank space when the block appears in your site. So
"The_Weather" block filename name will be changed to "Web Links". All this is
valid only if you don't set a title for your block when you add it.

