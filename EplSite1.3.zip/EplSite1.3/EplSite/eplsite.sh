#Set the path to Oracle Libraries
export LD_LIBRARY_PATH=/home/laran/Apps/instantclient_11_2
#Run eplsite preloading your modules
#In this file you can add or delete DBI/DBD modules preloaded.
#If you are running plackup from your Perl linux distribution:
plackup -MDBI -MDBD::SQLite -MDBD::CSV -MDBD::ODBC -MDBD::Oracle -MDBD::Pg -MDBD::mysql -MMIME::Base64 --loader Shotgun -s Starlet --port=3333 --timeout=3600 --max-workers=3 --access-log eplsite_access.log eplsite.pl

#If you are using ActiveState Perl, set the path to plackup 
#/home/laran/ActivePerl-5.16/site/bin/plackup -MDBI -MDBD::SQLite -MDBD::CSV -MDBD::ODBC -MDBD::Oracle -MDBD::Pg -MDBD::mysql -MMIME::Base64 --loader Shotgun -s Starlet --port=3333 --timeout=3600 --max-workers=2 --access-log eplsite_access.log eplsite.pl
